﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program8_6
{
    class clsCookies
    {
        // declare variables
        public string _CookieName;
        public double _CookiePrice;
        public decimal _CookieValue;
        public int _CookieCount;


        // Constructors
        public clsCookies(string CookieName, double CookiePrice, int CookieCount)
        {
            _CookieName = CookieName;
            _CookiePrice = CookiePrice;
            _CookieCount = CookieCount;
        }
        // methods
        public double CookieValue(int CookiesSold, decimal CookiePrice)
        {
            return (double)(CookiesSold * CookiePrice);
        }
        public void Sold (int Amount)
        {
            _CookieCount -= Amount;
        }
    }
}
