﻿
namespace Program8_6
{
    partial class frmCookieSale
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpCookieInfo = new System.Windows.Forms.GroupBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.numSold = new System.Windows.Forms.NumericUpDown();
            this.lblInvValue = new System.Windows.Forms.Label();
            this.lblCookieInv = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCookieName = new System.Windows.Forms.Label();
            this.lstCookies = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grpCookieInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSold)).BeginInit();
            this.SuspendLayout();
            // 
            // grpCookieInfo
            // 
            this.grpCookieInfo.Controls.Add(this.btnUpdate);
            this.grpCookieInfo.Controls.Add(this.numSold);
            this.grpCookieInfo.Controls.Add(this.lblInvValue);
            this.grpCookieInfo.Controls.Add(this.lblCookieInv);
            this.grpCookieInfo.Controls.Add(this.lblPrice);
            this.grpCookieInfo.Controls.Add(this.label6);
            this.grpCookieInfo.Controls.Add(this.label5);
            this.grpCookieInfo.Controls.Add(this.label3);
            this.grpCookieInfo.Controls.Add(this.label4);
            this.grpCookieInfo.Controls.Add(this.lblCookieName);
            this.grpCookieInfo.ForeColor = System.Drawing.Color.White;
            this.grpCookieInfo.Location = new System.Drawing.Point(336, 132);
            this.grpCookieInfo.Name = "grpCookieInfo";
            this.grpCookieInfo.Size = new System.Drawing.Size(348, 259);
            this.grpCookieInfo.TabIndex = 0;
            this.grpCookieInfo.TabStop = false;
            this.grpCookieInfo.Text = "CookieInfo";
            // 
            // btnUpdate
            // 
            this.btnUpdate.ForeColor = System.Drawing.Color.Black;
            this.btnUpdate.Location = new System.Drawing.Point(232, 208);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(100, 35);
            this.btnUpdate.TabIndex = 8;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // numSold
            // 
            this.numSold.Location = new System.Drawing.Point(188, 179);
            this.numSold.Name = "numSold";
            this.numSold.Size = new System.Drawing.Size(144, 23);
            this.numSold.TabIndex = 7;
            this.numSold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblInvValue
            // 
            this.lblInvValue.AutoSize = true;
            this.lblInvValue.Location = new System.Drawing.Point(296, 148);
            this.lblInvValue.Name = "lblInvValue";
            this.lblInvValue.Size = new System.Drawing.Size(13, 15);
            this.lblInvValue.TabIndex = 6;
            this.lblInvValue.Text = "0";
            // 
            // lblCookieInv
            // 
            this.lblCookieInv.AutoSize = true;
            this.lblCookieInv.Location = new System.Drawing.Point(296, 114);
            this.lblCookieInv.Name = "lblCookieInv";
            this.lblCookieInv.Size = new System.Drawing.Size(13, 15);
            this.lblCookieInv.TabIndex = 5;
            this.lblCookieInv.Text = "0";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(296, 78);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(13, 15);
            this.lblPrice.TabIndex = 4;
            this.lblPrice.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 15);
            this.label6.TabIndex = 3;
            this.label6.Text = "Sold:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "Inventory Value:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Price:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "Inventory:";
            // 
            // lblCookieName
            // 
            this.lblCookieName.AutoSize = true;
            this.lblCookieName.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCookieName.Location = new System.Drawing.Point(15, 29);
            this.lblCookieName.Name = "lblCookieName";
            this.lblCookieName.Size = new System.Drawing.Size(73, 28);
            this.lblCookieName.TabIndex = 0;
            this.lblCookieName.Text = "Cookie";
            // 
            // lstCookies
            // 
            this.lstCookies.FormattingEnabled = true;
            this.lstCookies.ItemHeight = 15;
            this.lstCookies.Location = new System.Drawing.Point(12, 132);
            this.lstCookies.Name = "lstCookies";
            this.lstCookies.Size = new System.Drawing.Size(288, 259);
            this.lstCookies.TabIndex = 1;
            this.lstCookies.SelectedIndexChanged += new System.EventHandler(this.lstCookies_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Kristen ITC", 42.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(444, 79);
            this.label1.TabIndex = 2;
            this.label1.Text = "Cookie Scouts";
            // 
            // frmCookieSale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(697, 402);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstCookies);
            this.Controls.Add(this.grpCookieInfo);
            this.Name = "frmCookieSale";
            this.Text = "Cookie Sales";
            this.Load += new System.EventHandler(this.frmCookieSale_Load);
            this.grpCookieInfo.ResumeLayout(false);
            this.grpCookieInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSold)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCookieInfo;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.NumericUpDown numSold;
        private System.Windows.Forms.Label lblInvValue;
        private System.Windows.Forms.Label lblCookieInv;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCookieName;
        private System.Windows.Forms.ListBox lstCookies;
        private System.Windows.Forms.Label label1;
    }
}

