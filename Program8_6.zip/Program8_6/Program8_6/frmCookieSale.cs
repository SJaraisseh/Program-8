﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program8_6
{
    public partial class frmCookieSale : Form
    {
        List<clsCookies> myCookies = new List<clsCookies>();
        public frmCookieSale()
        {
            InitializeComponent();
        }

        private void frmCookieSale_Load(object sender, EventArgs e)
        {
            // create new temp cookie list
            clsCookies tempCookie1 = new clsCookies("Peppermint Flatties", 4.99, 8);
            clsCookies tempCookie2 = new clsCookies("Chocolate Chippers", 4.76, 17);
            clsCookies tempCookie3 = new clsCookies("Pecan Paradise", 6.82, 9);
            clsCookies tempCookie4 = new clsCookies("Sugary Shortcake", 5.99, 12);

            // add to list
            myCookies.Add(tempCookie1);
            myCookies.Add(tempCookie2);
            myCookies.Add(tempCookie3);
            myCookies.Add(tempCookie4);
            // refresh list
            LoadListBox();
            // Default selected index
            Reset();            
        }
        
        private void LoadListBox()
        {
            // clear list box
            lstCookies.Items.Clear();
            // Loop through list and fill list box
            for (int i = 0; i < myCookies.Count; i++)
            {
                // add account holder name to list box
                lstCookies.Items.Add(myCookies[i]._CookieName);
            }
            Reset();
        }
        private void Reset()
        {
            lstCookies.SelectedIndex = 0;
            numSold.Value = 0;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // handle empty inventory
            if (numSold.Value > myCookies[lstCookies.SelectedIndex]._CookieCount)
            {
                MessageBox.Show("Amount exceeds current inventory count.");
                numSold.Focus();
                numSold.Value = 0;
            }
            else if (numSold.Value == 0)
            {
                MessageBox.Show("Amount must be greater than 0.");
            }
            else
            {
                // Sell 
                myCookies[lstCookies.SelectedIndex].Sold((int)numSold.Value);               
                // display total // update count
                MessageBox.Show("Subtotal: " + myCookies[lstCookies.SelectedIndex].CookieValue((int)numSold.Value, (decimal)myCookies[lstCookies.SelectedIndex]._CookiePrice).ToString("N2"));
                // reset
                Reset();
                // refresh list
                LoadListBox();
            }
        }

        private void lstCookies_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCookies.SelectedIndex > -1)
            {
                lblCookieName.Text = lstCookies.GetItemText(lstCookies.SelectedItem);
                lblPrice.Text = myCookies[lstCookies.SelectedIndex]._CookiePrice.ToString();
                lblCookieInv.Text = myCookies[lstCookies.SelectedIndex]._CookieCount.ToString();
                lblInvValue.Text = myCookies[lstCookies.SelectedIndex].CookieValue(myCookies[lstCookies.SelectedIndex]._CookieCount, (decimal)myCookies[lstCookies.SelectedIndex]._CookiePrice).ToString();
            }
        }
    }
}
